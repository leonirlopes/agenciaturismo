

<?php $__env->startSection('content'); ?>

<div class="bred">
    <a href="<?php echo e(route('panel')); ?>" class="bred">Home > </a>
    <a href="<?php echo e(route('airports.index', $city->id)); ?>" class="bred"> Cidade <?php echo e($city->name); ?> > </a>
    <a href="" class="bred">Editar</a>
</div>

<div class="title-pg">
    <h1 class="title-pg">Editar Aeroporto <?php echo e($airport->name); ?> para a cidade <?php echo e($city->name); ?></h1>
</div>

<div class="content-din">

<?php echo $__env->make('panel.includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::model($airport ,['route' => ['airports.update', $city->id, $airport->id], 'class' => 'form form-search form-ds', 'method' => 'PUT']); ?>

    <?php echo $__env->make('panel.airports.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo Form::close(); ?>


</div><!--Content Dinâmico-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>