

<?php $__env->startSection('content'); ?>

<div class="bred">
    <a href="<?php echo e(route('panel')); ?>" class="bred">Home  ></a>
    <a href="<?php echo e(route('states.index')); ?>" class="bred">Estados > </a>
    <a href="<?php echo e(route('state.cities', $state->initials)); ?>" class="bred"><?php echo e($state->name); ?> > </a>
    <a href="" class="bred">Cidades</a>
</div>

<div class="title-pg">
    <h1 class="title-pg">Cidades do Estado (<?php echo e($cities->count()); ?> - <?php echo e($cities->total()); ?>): <strong><?php echo e($state->name); ?></strong></h1>
</div>


<div class="content-din bg-white">

    <div class="form-search">
        <?php echo Form::open(['route' => ['state.cities.search', $state->initials], 'class' => 'form form-inline']); ?>

            <?php echo Form::text('key_search', null, ['class' => 'form-control', 'placeholder' => 'O que deseja encontrar?']); ?>


            <button class="btn btn-search">Pesquisar</button>
        <?php echo Form::close(); ?>


        <?php if(isset($dataForm['key_search'])): ?>
            <div class="alert alert-info">
                <p>
                    <a href=""><i class="fa fa-refresh" aria-hidden="true"></i></a>
                    Resultados para: <strong><?php echo e($dataForm['key_search']); ?></strong>
                </p>
            </div>
        <?php endif; ?>
    </div>

    <div class="messages">
        <?php echo $__env->make('panel.includes.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    
    <table class="table table-striped">
        <tr>
            <th>Nome</th>
            <th width="200">Ações</th>
        </tr>

        <?php $__empty_1 = true; $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($city->name); ?></td>
                <td>
                    <a href="<?php echo e(route('airports.index', $city->id)); ?>" class="edit">
                        <i class="fa fa-thumb-tack" aria-hidden="true"></i>
                        Aeroportos
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="200">Nenhum item cadastrado!</td>
            </tr>
        <?php endif; ?>
    </table>

    <?php if(isset($dataForm)): ?>
        <?php echo $cities->appends($dataForm)->links(); ?>

    <?php else: ?>
        <?php echo $cities->links(); ?>

    <?php endif; ?>

</div><!--Content Dinâmico-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>