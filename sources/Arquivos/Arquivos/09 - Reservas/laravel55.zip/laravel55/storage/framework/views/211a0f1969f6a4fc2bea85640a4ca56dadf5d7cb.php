

<?php $__env->startSection('content'); ?>

<div class="bred">
    <a href="<?php echo e(route('panel')); ?>" class="bred">Home > </a>
    <a href="<?php echo e(route('brands.index')); ?>" class="bred">Marcas > </a>
    <a href="" class="bred"><?php echo e($brand->name); ?></a>
</div>

<div class="title-pg">
    <h1 class="title-pg"><?php echo e($brand->name); ?></h1>
</div>

<div class="content-din">
    <ul>
        <li>
            Nome: <strong><?php echo e($brand->name); ?></strong>
        </li>
    </ul>

<?php echo $__env->make('panel.includes.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::open(['route' => ['brands.destroy', $brand->id], 'class' => 'form form-search form-ds', 'method' => 'DELETE']); ?>

    <div class="form-group">
        <button class="btn btn-danger">Deletar a marca <?php echo e($brand->name); ?></button>
    </div>
<?php echo Form::close(); ?>


</div><!--Content Dinâmico-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>