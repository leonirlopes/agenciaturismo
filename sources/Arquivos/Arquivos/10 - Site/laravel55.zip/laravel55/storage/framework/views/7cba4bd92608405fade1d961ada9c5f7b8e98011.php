<div class="form-search">
    <?php echo Form::open(['route' => 'reserves.search', 'class' => 'form form-inline']); ?>

        <?php echo Form::text('user', null, ['class' => 'form-control', 'placeholder' => 'Detalhes do Usuário?']); ?>


        <?php echo Form::text('reserve', null, ['class' => 'form-control', 'placeholder' => 'Detalhes da Reserva?']); ?>


        <?php echo Form::date('date', null, ['class' => 'form-control', 'placeholder' => 'Data do Voo']); ?>


        <?php echo Form::select('status', [
                            'reserved'  => 'Reservado',
                            'canceled'  => 'Cancelado',
                            'paid'      => 'Pago',
                            'concluded' => 'Concluído',
                        ], null, ['class' => 'form-control']); ?>


        <button class="btn btn-search">Pesquisar</button>
    <?php echo Form::close(); ?>


    <?php if(isset($dataForm['key_search'])): ?>
        <div class="alert alert-info">
            <p>
                <a href="<?php echo e(route('planes.index')); ?>"><i class="fa fa-refresh" aria-hidden="true"></i></a>
                Resultados para: <strong><?php echo e($dataForm['key_search']); ?></strong>
            </p>
        </div>
    <?php endif; ?>
</div>