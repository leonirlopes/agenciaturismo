

<?php $__env->startSection('content-site'); ?>

<div class="content text-center">
    <img src="<?php echo e(url('assets/site/images/error-404.png')); ?>" alt="404">
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>