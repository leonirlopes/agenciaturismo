

<?php $__env->startSection('content-site'); ?>

<div class="content">

    <section class="container">
        <h1 class="title">Detalhes do voô <?php echo e($flight->id); ?></h1>


        <ul>
            <li>
                Código: <strong><?php echo e($flight->id); ?></strong>
            </li>
            <li>
                Origem: <strong><?php echo e($flight->origin->name); ?></strong>
            </li>
            <li>
                Destino: <strong><?php echo e($flight->destination->name); ?></strong>
            </li>
            <li>
                Data: <strong><?php echo e(formatDateAndTime($flight->date)); ?></strong>
            </li>
            <li>
                Duração: <strong><?php echo e(formatDateAndTime($flight->time_duration, 'H:i')); ?></strong>
            </li>
            <li>
                Saída: <strong><?php echo e(formatDateAndTime($flight->hour_output, 'H:i')); ?></strong>
            </li>
            <li>
                Chegada: <strong><?php echo e(formatDateAndTime($flight->arrival_time, 'H:i')); ?></strong>
            </li>
            <li>
                Valor Anterior: <strong> R$ <?php echo e(number_format($flight->old_price, 2, ',', '.')); ?></strong>
            </li>
            <li>
                Valor Atual: <strong> R$ <?php echo e(number_format($flight->price, 2, ',', '.')); ?></strong>
            </li>
            <li>
                Total de Parcelas: <strong><?php echo e($flight->total_plots); ?></strong>
            </li>
            <li>
                Promoção: <strong><?php echo e($flight->is_promotion ? 'SIM' : 'NÃO'); ?></strong>
            </li>
            <li>
                Paradas: <strong><?php echo e($flight->qty_stops); ?></strong>
            </li>
            <li>
                Descrição: <strong><?php echo e($flight->description); ?></strong>
            </li>        
        </ul>


        <?php echo $__env->make('panel.includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo Form::open(['route' => 'reserve.flight']); ?>

            <?php echo Form::hidden('user_id', auth()->user()->id); ?>

            <?php echo Form::hidden('flight_id', $flight->id); ?>

            <?php echo Form::hidden('date_reserved', date('Y-m-d')); ?>

            <?php echo Form::hidden('status', 'reserved'); ?>


            <button type="submit" class="btn btn-success">Reservar Agora</button>
        <?php echo Form::close(); ?>


    </section><!--Container-->

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>