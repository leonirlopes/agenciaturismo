<div class="form-group">
    <label for="name">Nome</label>
    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <label for="latitude">Latitude</label>
    <?php echo Form::text('latitude', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <label for="longitude">Longitude</label>
    <?php echo Form::text('longitude', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <label for="address">Endereço</label>
    <?php echo Form::text('address', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <label for="number">Número</label>
    <?php echo Form::number('number', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <label for="zip_code">Código Postal</label>
    <?php echo Form::text('zip_code', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <label for="complement">Complemento</label>
    <?php echo Form::text('complement', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <button class="btn btn-search">Enviar</button>
</div>