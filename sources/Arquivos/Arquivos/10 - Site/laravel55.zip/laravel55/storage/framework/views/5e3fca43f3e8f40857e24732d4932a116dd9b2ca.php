

<?php $__env->startSection('content'); ?>

<div class="bred">
    <a href="<?php echo e(route('panel')); ?>" class="bred">Home > </a>
    <a href="<?php echo e(route('airports.index', $city->id)); ?>" class="bred"> Cidade <?php echo e($city->name); ?> > </a>
    <a href="" class="bred">Detalhes do Aeroporto</a>
</div>

<div class="title-pg">
    <h1 class="title-pg"><?php echo e($airport->name); ?> - <?php echo e($city->name); ?></h1>
</div>

<div class="content-din">
    <ul>
        <li>
            Nome: <strong><?php echo e($airport->name); ?></strong>
        </li>
        <li>
            Latitude: <strong><?php echo e($airport->latitude); ?></strong>
        </li>
        <li>
            Longitude: <strong><?php echo e($airport->longitude); ?></strong>
        </li>
        <li>
            Endereço: <strong><?php echo e($airport->address); ?></strong>
        </li>
        <li>
            Número: <strong><?php echo e($airport->number); ?></strong>
        </li>
        <li>
            Código Postal: <strong><?php echo e($airport->zip_code); ?></strong>
        </li>
        <li>
            Complemento: <strong><?php echo e($airport->complement); ?></strong>
        </li>
    </ul>

<?php echo $__env->make('panel.includes.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::open(['route' => ['airports.destroy', $city->id, $airport->id], 'class' => 'form form-search form-ds', 'method' => 'DELETE']); ?>

    <div class="form-group">
        <button class="btn btn-danger">Deletar o aeroporto: <?php echo e($airport->name); ?></button>
    </div>
<?php echo Form::close(); ?>


</div><!--Content Dinâmico-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>