

<?php $__env->startSection('content-site'); ?>

<div class="content">

    <section class="container">
        <h1 class="title">Resultados Pesquisa:</h1>
        <div class="key-search row">
            <div class="col-lg-2 col-md-2 col-sm-12 col-12 text-center">
                <img src="<?php echo e(url('assets/site/images/flight.png')); ?>" alt="Voô">
            </div>
            <div class="col-lg-10 col-md-10 col-sm-12 col-12">
                <p>De: <span><?php echo e($origin); ?></span></p>
                <p>Para: <span><?php echo e($destionation); ?></span></p>
                <p>Data: <span><?php echo e($date); ?></span></p>
            </div>
        </div>


        <div class="row results-search">
            <?php $__empty_1 = true; $__currentLoopData = $flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="result-search col-12">

                    <span>Saída: <strong><?php echo e(formatDateAndTime($flight->hour_output, 'H:i')); ?></strong></span>
                    <span>Chegada: <strong><?php echo e(formatDateAndTime($flight->arrival_time, 'H:i')); ?></strong></span>
                    <span>Paradas: <strong><?php echo e($flight->qty_stops); ?></strong></span>
                    <a href="<?php echo e(route('details.flight', $flight->id)); ?>">Detalhes</a>

                </article><!--result-search-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Nenhum Resultado Para a Pesquisa!</p>
            <?php endif; ?>
        </div><!--Row-->
    </section><!--Container-->

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>