@extends('site.layouts.app')

@section('content-site')

<div class="content text-center">
    <img src="{{ url('assets/site/images/error-404.png') }}" alt="404">
</div>

@endsection