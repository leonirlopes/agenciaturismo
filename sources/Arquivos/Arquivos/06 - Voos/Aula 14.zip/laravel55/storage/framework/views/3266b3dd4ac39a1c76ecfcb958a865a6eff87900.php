

<?php $__env->startSection('content'); ?>

<div class="bred">
    <a href="<?php echo e(route('panel')); ?>" class="bred">Home > </a>
    <a href="<?php echo e(route('flights.index')); ?>" class="bred">Voos > </a>
    <a href="" class="bred"><?php echo e($flight->id); ?></a>
</div>

<div class="title-pg">
    <h1 class="title-pg">Detalhes do voo: <?php echo e($flight->id); ?></h1>
</div>

<div class="content-din">
    <ul>
        <li>
            Código: <strong><?php echo e($flight->id); ?></strong>
        </li>
        <li>
            Origem: <strong><?php echo e($flight->origin->name); ?></strong>
        </li>
        <li>
            Destino: <strong><?php echo e($flight->destination->name); ?></strong>
        </li>
        <li>
            Data: <strong><?php echo e(formatDateAndTime($flight->date)); ?></strong>
        </li>
        <li>
            Duração: <strong><?php echo e(formatDateAndTime($flight->time_duration, 'H:i')); ?></strong>
        </li>
        <li>
            Saída: <strong><?php echo e(formatDateAndTime($flight->hour_output, 'H:i')); ?></strong>
        </li>
        <li>
            Chegada: <strong><?php echo e(formatDateAndTime($flight->arrival_time, 'H:i')); ?></strong>
        </li>
        <li>
            Valor Anterior: <strong> R$ <?php echo e(number_format($flight->old_price, 2, ',', '.')); ?></strong>
        </li>
        <li>
            Valor Atual: <strong> R$ <?php echo e(number_format($flight->price, 2, ',', '.')); ?></strong>
        </li>
        <li>
            Total de Parcelas: <strong><?php echo e($flight->total_plots); ?></strong>
        </li>
        <li>
            Promoção: <strong><?php echo e($flight->is_promotion ? 'SIM' : 'NÃO'); ?></strong>
        </li>
        <li>
            Paradas: <strong><?php echo e($flight->qty_stops); ?></strong>
        </li>
        <li>
            Descrição: <strong><?php echo e($flight->description); ?></strong>
        </li>        
    </ul>

<?php echo $__env->make('panel.includes.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::open(['route' => ['flights.destroy', $flight->id], 'class' => 'form form-search form-ds', 'method' => 'DELETE']); ?>

    <div class="form-group">
        <button class="btn btn-danger">Deletar o voo <?php echo e($flight->id); ?></button>
    </div>
<?php echo Form::close(); ?>


</div><!--Content Dinâmico-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>