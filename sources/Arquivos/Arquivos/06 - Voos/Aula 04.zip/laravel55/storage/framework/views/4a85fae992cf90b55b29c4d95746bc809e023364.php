

<?php $__env->startSection('content'); ?>

<div class="bred">
    <a href="<?php echo e(route('panel')); ?>" class="bred">Home > </a>
    <a href="<?php echo e(route('planes.index')); ?>" class="bred">Planes > </a>
    <a href="" class="bred"><?php echo e($plane->id); ?></a>
</div>

<div class="title-pg">
    <h1 class="title-pg"><?php echo e($plane->name); ?></h1>
</div>

<div class="content-din">
    <ul>
        <li>
            Código: <strong><?php echo e($plane->id); ?></strong>
        </li>
        <li>
            Marca: <strong><?php echo e($brand); ?></strong>
        </li>
        <li>
            Quantidade de Passageiros: <strong><?php echo e($plane->qty_passengers); ?></strong>
        </li>
    </ul>

<?php echo $__env->make('panel.includes.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::open(['route' => ['planes.destroy', $plane->id], 'class' => 'form form-search form-ds', 'method' => 'DELETE']); ?>

    <div class="form-group">
        <button class="btn btn-danger">Deletar o avião <?php echo e($plane->name); ?></button>
    </div>
<?php echo Form::close(); ?>


</div><!--Content Dinâmico-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>