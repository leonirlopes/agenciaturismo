<div class="form-group">
    <label for="plane_id">Escolha o avião</label>
    <?php echo Form::select('plane_id', $planes, null, ['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <label for="airport_origin_id">Origem</label>
    <?php echo Form::select('airport_origin_id', $airports, null, ['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <label for="airport_destination_id">Destino</label>
    <?php echo Form::select('airport_destination_id', $airports, null, ['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <label for="date">Data</label>
    <?php echo Form::date('date', null, ['class' => 'form-control', 'placeholder' => 'Data']); ?>

</div>
<div class="form-group">
    <label for="time_duration">Duração</label>
    <?php echo Form::time('time_duration', null, ['class' => 'form-control', 'placeholder' => 'Duração']); ?>

</div>
<div class="form-group">
    <label for="hour_output">Horas Saída</label>
    <?php echo Form::time('hour_output', null, ['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <label for="arrival_time">Horas Chegada</label>
    <?php echo Form::time('arrival_time', null, ['class' => 'form-control', 'placeholder' => 'Horas Chegada']); ?>

</div>
<div class="form-group">
    <label for="old_price">Preço Anterior</label>
    <?php echo Form::text('old_price', null, ['class' => 'form-control', 'placeholder' => 'Preço Anterior']); ?>

</div>
<div class="form-group">
    <label for="price">Preço</label>
    <?php echo Form::text('price', null, ['class' => 'form-control', 'placeholder' => 'Preço']); ?>

</div>
<div class="form-group">
    <label for="price">Total de Parelas</label>
    <?php echo Form::number('total_plots', null, ['class' => 'form-control', 'placeholder' => 'Total de Parelas']); ?>

</div>
<div class="form-group">
    <?php echo Form::checkbox('is_promotion', null, null, ['id' => 'is_promotion']); ?>

    <label for="price">É promoção?</label>
</div>
<div class="form-group">
    <label for="image">Foto</label>
    <?php echo Form::file('image', ['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <label for="price">Quantidade de paradas</label>
    <?php echo Form::number('qty_stops', null, ['class' => 'form-control', 'placeholder' => 'Quantidade de paradas']); ?>

</div>
<div class="form-group">
    <label for="price">Descrição</label>
    <?php echo Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => 'Descrição do voo']); ?>

</div>

<div class="form-group">
    <button class="btn btn-search">Enviar</button>
</div>