

<?php $__env->startSection('content'); ?>

<div class="bred">
    <a href="" class="bred">Home  ></a>
    <a href="" class="bred">Brands</a>
</div>

<div class="title-pg">
    <h1 class="title-pg">Marcas de Aviões</h1>
</div>


<div class="content-din bg-white">

    <div class="form-search">
        <?php echo Form::open(['route' => 'brands.search', 'class' => 'form form-inline']); ?>

            <?php echo Form::text('key_search', null, ['class' => 'form-control', 'placeholder' => 'O que deseja encontrar?']); ?>


            <button class="btn btn-search">Pesquisar</button>
        <?php echo Form::close(); ?>


        <?php if(isset($dataForm['key_search'])): ?>
            <div class="alert alert-info">
                <p>
                    <a href="<?php echo e(route('brands.index')); ?>"><i class="fa fa-refresh" aria-hidden="true"></i></a>
                    Resultados para: <strong><?php echo e($dataForm['key_search']); ?></strong>
                </p>
            </div>
        <?php endif; ?>
    </div>

    <div class="messages">
        <?php echo $__env->make('panel.includes.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="class-btn-insert">
        <a href="<?php echo e(route('brands.create')); ?>" class="btn-insert">
            <span class="glyphicon glyphicon-plus"></span>
            Cadastrar
        </a>
    </div>
    
    <table class="table table-striped">
        <tr>
            <th>Nome</th>
            <th width="150">Ações</th>
        </tr>

        <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($brand->name); ?></td>
                <td>
                    <a href="<?php echo e(route('brands.edit', $brand->id)); ?>" class="edit">Edit</a>
                    <a href="<?php echo e(route('brands.show', $brand->id)); ?>" class="delete">View</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="200">Nenhum item cadastrado!</td>
            </tr>
        <?php endif; ?>
    </table>

    <?php if(isset($dataForm)): ?>
        <?php echo $brands->appends($dataForm)->links(); ?>

    <?php else: ?>
        <?php echo $brands->links(); ?>

    <?php endif; ?>

</div><!--Content Dinâmico-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>