<?php $__env->startSection('content-site'); ?>
<div class="content">
    <div class="container">
        <h1 class="title">Alterar a Senha</h1>

        <form class="form-horizontal" method="POST" action="<?php echo e(route('password.request')); ?>">
            <?php echo e(csrf_field()); ?>


            <input type="hidden" name="token" value="<?php echo e($token); ?>">

            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <label for="email" class="control-label">E-Mail</label>

                <div>
                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(isset($email) ? $email : old('email')); ?>" required autofocus>

                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <label for="password" class="control-label">Nova Senha</label>

                <div>
                    <input id="password" type="password" class="form-control" name="password" required>

                    <?php if($errors->has('password')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                <label for="password-confirm" class="control-label">Confirmar Senha</label>
                <div>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>

                    <?php if($errors->has('password_confirmation')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <div>
                    <button type="submit" class="btn btn-primary">
                        Alterar a Senha
                    </button>
                </div>
            </div>
        </form>

    </div><!--container-->
</div><!--content-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>